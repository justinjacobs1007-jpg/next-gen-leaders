# Next Gen Leaders Website

This is a standalone, responsive website with no paid software required.

## Files
- index.html — the complete website (HTML + CSS + JavaScript in one file)

## Before publishing
1. Open index.html in a browser to preview it.
2. Replace `hello@nextgenleaders.org` in the contact form with your real email.
3. Update any wording, links, social media, and program information you want.

## Free hosting
You can publish this site for $0 using a static-hosting service such as GitHub Pages, Cloudflare Pages, or Netlify's free tier. A custom domain is optional and normally costs money; the free hosting address does not.

## Design
The site uses a clean civic/leadership style with navy, blue, white, and a small gold accent. Everything is contained in index.html, so it is easy to edit.
